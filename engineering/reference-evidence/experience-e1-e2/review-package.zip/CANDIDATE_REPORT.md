# EXPERIENCE E1/E2 — candidate review

**Creative-review candidate. Canonical promotion remains HOLD. No merge, default cutover or production publication.**

- Candidate: `1fe72f3eea5eb31ad63493d87043e1d5a9751478`, `rally-one/experience-e1-e2`, draft PR157.
- Direct parent: physically/visually accepted2D `08e33bf1ab043c8225e0e687de8371ed53c6298f` (PR156 frozen).
- Canonical: `076a3393eef013304e715c6bc283031af4040df1`, unchanged.
- Immutable preview: https://6b08ee275fb317703d332f7d--citizen-connect-test.netlify.app/foundation2/
- Legacy entry: https://6b08ee275fb317703d332f7d--citizen-connect-test.netlify.app/?rallyOne=1
- PR: https://github.com/woodrow5087-hue/Citizen-groups/pull/157

## Visible journey improvements

Existing member name/involvement is visible on Today with an accessible Edit profile entry to the same guarded dialog and focus restoration. Native agenda links open Groups/Team without confirming a response or marking conversations read; Back restores the originating row. Visitors get direct local discovery in Groups, reversible interest and unchanged permissions, with the old full-demo fallback retained. Unknown conversation/serving states lead to safe in-app review instead of false completion or an unnecessary legacy jump. Compact community controls retain all authorized people/prayer/leader/Room functions. Existing intelligence, event identities, storage, care, conversation cursors/drafts and game progress owners remain unchanged.

## Reusable visual foundation

State-free `foundation2/widgets.js` supplies escaped section headers, consistent outline icons and validated internal utility links; no context, IO, listener or store ownership. Existing `design.css` owns type/space/radius/control tokens and the matte charcoal/graphite/cream/Citizen-red system. Today preserves cream primary → explicit secondary commitments → actionable schedule → optional utility/community. Smaller image/card whitespace, compact shared header controls and cream active-navigation icon recover approved concepts without hiding responsibilities or adding a carousel. Read/Connect/game internals are not redesigned.

References distinguish approved UX02ef4b8e7 from Studio13c7928f6 creative-only evidence. Supplied Studio13 photo/reference HTML remains private/unpublished. Only existing approved repository imagery/fonts are used. No older application or prototype state engine was transplanted; no new baselines are pinned.

## Before/after review

Open visual-review.html or visual-review.pdf for six role pairs and full-height links. Captures use390x844, Nov26,2026 noonUTC, Denver timezone, the same synthetic name and explicit actions. Source08e33bf is the before build;1fe72f3 is candidate. Screenshots are review evidence, not immutable references.

| Role | Before Today content height | Candidate | Reduction |
|---|---:|---:|---:|
| Visitor |747px|619px|128px|
| Group member |763px|655px|108px|
| Volunteer |706px|626px|80px|
| Combined |933px|798px|135px|
| Authorized leader |1362px|1033px|329px|
| All Set |863px|728px|135px|

These are reproducible fixture geometry measurements, not universal fit/performance claims. Long leader content and larger text remain scrollable.

## Applicable validation

- Locked install, build and independent exact-source archive build passed.
- 968 application tests;172 VersePlay units passed.
- 72 Foundation scenes; existing2B/2C/2D browser suites passed.
- New four-role Chromium and genuine WebKit27.2 journeys passed at320/375/390/430, short viewport,200% text, reduced motion, profile/campus reload, agenda read-only/focus, discovery interest/permissions, AllSet/deferred/unavailable distinctions, Ask no writes/read marks, original-key isolation, zero page errors/axe violations.
- VersePlay433 browser checks/49 visual comparisons passed; no console/font failures.
- 186 non-Foundation published files byte-match accepted2D. Protected engines/state owners unchanged.
- 212 deployed files verified against independent git-archive build; only the documented Netlify PrettyURLs legacy-link rewrite differs. Provider metadata is exact1fe72f3, deploy-preview ready, published_at:null; native GitHub Netlify SUCCESS. Deployed publication/date/legacy-return and four-width E1/E2 journeys passed.
- Foundation CI45929940364 passed at the exact head. Full QA45929940484 final result follows in the closeout section.

Local validation caught and corrected accessible-name mismatch and a duplicate partial accessible-name match with the existing profile menu. Existing assertions were preserved; the new inline action is uniquely named Edit profile for [name]. No remote debugging/retry cycle was used.

## Preservation / limits

Owner2D acceptance is recorded:2/2 official Safari/VoiceOver journeys,12/12 supplemental items and final visual acceptance; iPhone18 Pro/iOS27.2.1(24B156). New tag rally-one/checkpoints/2026-11-27-convergence-2d-accepted pins08e33bf; no existing ref was overwritten. PR156 source and passing/failing evidence remain preserved. Canonical, main/production, PR150 and18 prior protected refs remain unchanged. The sole authoritative repository tracker is engineering/foundation2-development-program.md; this PR records exact-head closeout without a documentation-only source change.

Canonical and2D protected visual failures remain unresolved, not passing gates; no new SVG investigation, blind retry, threshold change, pixel mask or reference replacement. Issue153 remains explicitly deferred and untouched. Any current passing comparison does not explain or erase prior failed evidence. All data/communications remain synthetic/local. Real joining, live delivery/auth/provider records and destructive migration are excluded. The legacy root remains default; Foundation is opt-in.

## Targeted owner review / next block

1. Review Today across visitor, group member, volunteer, combined and leader: priority hierarchy, name/involvement, cream/red balance, compact community controls, All Set versus deferred/unavailable, and shared active-navigation treatment. No new reference approval is assumed.
2. On Safari/VoiceOver, check the new name → edit/save/reload/focus path and agenda → Groups/Team → Back; visitor Today → Groups → discovery/interest/undo and close focus; larger text/short viewport/primary navigation. Existing2D unchanged messaging/game-engine acceptance carries forward; no blanket repeat of12 items.

Stop for creative acceptance before broader visual rollout. Proposed next block after approval: apply approved primitives coherently to Groups/Team content and refine restrained press/route transitions with focus/reduced-motion tests. Premium Connect and VersePlay identities remain protected. No next implementation lane or promotion has started.

## Exact-head closeout

Foundation45929940364 PASSED; full QA45929940484 PASSED at1fe72f3. Full QA verified968 units, all configured functional/mobile/synthetic stages,64 historical pairs at zero raw pixels with75 source guards, and86 strict Connect pairs at zero raw pixels with10 source guards (WebKit27.2). Native Netlify status SUCCESS and all212 deployed files verified. No retry was initiated.

**Owner creative review is now the next step. Promotion remains HOLD:** the passing candidate does not explain or clear the earlier canonical/2D protected failures or deferred153. All failed evidence remains preserved. No merge, production/default cutover or broader visual rollout occurred. The only active product lane is this descendant of accepted2D; the accepted checkpoint and all prior references remain unchanged.
