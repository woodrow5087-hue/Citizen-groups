# Foundation reference review — PR #152

Source: `37c4be939a03071d8fdae746eb14b501849b9063` (clean). Manifest SHA256: `87418a8d58c72b2e08dd0e485f580cadeb6fe4ab1c3410db36a64f2ede8c57d7`. Inventory: exactly 72 PNG captures. All source hashes and image hashes reverified without rerunning acceptance tests.

Owner physical acceptance: 3/3 confirmed on this head; prior Gate 8 evidence carries forward. Device/iOS details were not supplied and are not inferred. This record does not approve a new visual baseline or promotion.

Open `review.html`: it is a self-contained gallery with all 72 captures, category/width filtering, full-size viewing and per-image hashes. Source filenames are the scenario labels; no screenshot was edited or regenerated. Representative full-size views appear after the inventory.

Material distinctions / limitations:

- Historical clock `2026-11-26T00:45:00.000Z`; Chromium `159.0.8154.6`. Historical synthetic dates intentionally remain in these regression fixtures. They are not the deployed December 2 sample snapshot.
- These captures come from the existing source-server acceptance fixture, not screenshots of Netlify output. Source/build distinction is retained. Deployed disclosure and December 5/6 samples were separately verified and physically accepted; supplementary images are clearly outside this 72-image inventory.
- Full-page screenshots exceed the viewport height. Fixed navigation can appear partway through a tall screenshot; this reflects the capture method, not a newly asserted layout defect.
- Coverage uses 320/390/430px plus explicit enlarged-text scenes. There is no 375px image in this inventory; separate deployed checks covered 375px. No absent scene is implied.
- Existing report: 72 scenes, zero page errors, zero axe violations. This is not a claim of approved Foundation pixel equivalence yet. No material new regression was established during organization; no new pixel comparison has run.

Approval request: approve this exact 72-image inventory and manifest as the Foundation regression checkpoint. It is not a permanent design lock: future intentional changes can receive scoped owner review and a separately traceable reference revision. It is not merge authorization.

After explicit approval only: establish independent immutable source reconstruction and exact-inventory zero-raw-pixel comparison; run applicable validation and exact-head deployment verification. Carry physical acceptance forward if runtime is byte-equivalent. Remain on PR #152. Do not start 2B or promote canonical without separate authorization.
