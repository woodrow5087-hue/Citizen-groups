// Approved source and captured inventory are independent of the candidate.
import assert from 'node:assert/strict';
import {readFile,mkdir,mkdtemp,rm,symlink,readdir,writeFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {resolve,join} from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync,spawnSync} from 'node:child_process';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),{PNG}=require('pngjs');
const root=resolve(import.meta.dirname,'..');
const approved='37c4be939a03071d8fdae746eb14b501849b9063';
const manifestHash='87418a8d58c72b2e08dd0e485f580cadeb6fe4ab1c3410db36a64f2ede8c57d7';
const ref=join(root,'test/references/foundation2'),out=join(root,'test-results/foundation2-visual');
const hash=b=>createHash('sha256').update(b).digest('hex');
const git=(cwd,...args)=>execFileSync('git',args,{cwd});
await mkdir(out,{recursive:true});
const report={approvedSource:approved,manifestSHA256:manifestHash,rawDifferentPixels:0,pairs:[],errors:[]};
let temp;
try{
 const bytes=await readFile(join(ref,'manifest.json'));assert.equal(hash(bytes),manifestHash);
 const manifest=JSON.parse(bytes);assert.equal(manifest.sourceCommit,approved);assert.equal(manifest.sourceStatus,'');
 const names=Object.keys(manifest.captures).sort();assert.equal(names.length,72);
 assert.deepEqual((await readdir(ref)).filter(f=>f.endsWith('.png')).sort(),names);
 // Fetch only this immutable object if the CI checkout is shallow.
 try{git(root,'cat-file','-e',approved+'^{commit}');}catch{git(root,'fetch','--no-tags','origin',approved);}
 temp=await mkdtemp(join(tmpdir(),'foundation-approved-'));
 git(temp,'init','-q');git(temp,'fetch','--quiet','--update-shallow',root,approved);git(temp,'checkout','--quiet','--detach','FETCH_HEAD');
 assert.equal(git(temp,'rev-parse','HEAD').toString().trim(),approved);
 for(const [file,expected] of Object.entries(manifest.sources))assert.equal(hash(await readFile(join(temp,file))),expected,'Approved source hash: '+file);
 for(const name of names)assert.equal(hash(await readFile(join(ref,name))),manifest.captures[name],'Approved PNG hash: '+name);
 // Reconstruct with the candidate's locked toolchain; exact browser version is verified below.
 assert.equal(hash(await readFile(join(temp,'package-lock.json'))),hash(await readFile(join(root,'package-lock.json'))),'Dependency identity changed; reference environment review required');
 // Same capture harness for both independently verified application trees.
 const harness=await readFile(join(root,'scripts/foundation2-browser-check.mjs'));
 await writeFile(join(temp,'scripts/foundation2-browser-check.mjs'),harness);
 await symlink(join(root,'node_modules'),join(temp,'node_modules'),'dir');
 for(const [source,directory] of [[temp,join(out,'reconstructed')],[root,join(out,'candidate')]]){
  await rm(directory,{recursive:true,force:true});
  const run=spawnSync(process.execPath,[join(source,'scripts/foundation2-browser-check.mjs')],{cwd:source,env:{...process.env,FOUNDATION_OUTPUT_DIR:directory},encoding:'utf8',maxBuffer:8*1024*1024});
  // Original approved script predates configurable output and writes its own fixed directory.
  assert.equal(run.status,0,run.stdout+'\n'+run.stderr);
 }
 const reconstructed=join(out,'reconstructed'),candidate=join(out,'candidate');
 for(const directory of [reconstructed,candidate]){
  const capture=JSON.parse(await readFile(join(directory,'candidate-manifest.json')));
  assert.equal(capture.browserVersion,manifest.browserVersion,'Browser identity drift');
  assert.equal(capture.historicalClock,manifest.historicalClock,'Clock drift');
  assert.deepEqual(Object.keys(capture.captures).sort(),names,'Capture inventory drift');
  assert.deepEqual((await readdir(directory)).filter(f=>f.endsWith('.png')).sort(),names,'Unexpected/missing images');
 }
 function compare(a,b,label){
  const x=PNG.sync.read(a),y=PNG.sync.read(b);assert.equal(x.width,y.width,label+' width');assert.equal(x.height,y.height,label+' height');
  let different=0;for(let i=0;i<x.data.length;i+=4)if(x.data[i]!==y.data[i]||x.data[i+1]!==y.data[i+1]||x.data[i+2]!==y.data[i+2]||x.data[i+3]!==y.data[i+3])different++;
  assert.equal(different,0,label+' raw pixel difference');return different;
 }
 for(const name of names){
  const reference=await readFile(join(ref,name)),fresh=await readFile(join(reconstructed,name)),actual=await readFile(join(candidate,name));
  compare(reference,fresh,'Independent reconstruction '+name);compare(reference,actual,'Candidate '+name);
  report.pairs.push({file:name,reconstructionRawPixels:0,candidateRawPixels:0});
 }
 console.log('Foundation immutable visual regression: 72 reconstructed references + 72 candidate comparisons; zero raw pixel differences.');
}catch(e){report.errors.push(e.stack);throw e;}finally{
 await writeFile(join(out,'results.json'),JSON.stringify(report,null,2));
 if(temp)await rm(temp,{recursive:true,force:true});
}
