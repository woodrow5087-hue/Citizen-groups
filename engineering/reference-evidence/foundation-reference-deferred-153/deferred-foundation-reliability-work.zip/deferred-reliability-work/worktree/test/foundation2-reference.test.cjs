'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
test('owner-approved Foundation manifest and all 72 image identities remain immutable',()=>{
 const root=path.join(__dirname,'references/foundation2'),bytes=fs.readFileSync(path.join(root,'manifest.json'));
 const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
 assert.equal(hash(bytes),'87418a8d58c72b2e08dd0e485f580cadeb6fe4ab1c3410db36a64f2ede8c57d7');
 const m=JSON.parse(bytes);assert.equal(m.sourceCommit,'37c4be939a03071d8fdae746eb14b501849b9063');
 const names=Object.keys(m.captures).sort();assert.equal(names.length,72);
 assert.deepEqual(fs.readdirSync(root).filter(f=>f.endsWith('.png')).sort(),names);
 for(const name of names)assert.equal(hash(fs.readFileSync(path.join(root,name))),m.captures[name],name);
});
