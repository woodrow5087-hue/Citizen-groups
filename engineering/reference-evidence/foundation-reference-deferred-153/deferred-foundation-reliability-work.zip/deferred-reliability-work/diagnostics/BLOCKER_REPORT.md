# CONVERGENCE 2A reference acceptance — HOLD

PR #152 remains draft/open at `37c4be939a03071d8fdae746eb14b501849b9063`. No new commit or push was made. The existing exact-head preview remains https://6b087f7a0398cba1c9599fc1--citizen-connect-test.netlify.app/foundation2/ . Its previously passing CI is preserved; it does not validate the new uncommitted comparison implementation.

Owner approval is recorded for all 72 images and manifest SHA256 `87418a8d58c72b2e08dd0e485f580cadeb6fe4ab1c3410db36a64f2ede8c57d7`. Original manifest and all image bytes remain unchanged. Physical Safari/VoiceOver 3/3 and Gate 8 evidence carry forward. No new physical execution is required by these tooling-only changes.

## Completed work

A local fail-closed comparator pins the source/manifest, independently checks out the approved Git commit, verifies every original source hash and PNG hash, and captures approved application and candidate separately. It checks exact 72-scene inventories, dependency lock, browser version, clock, dimensions and zero raw RGBA pixel differences. The pipeline retains all functional/accessibility assertions. The application unit suite passed 932 tests; the reference integrity guard also passed after approval recording.

## Blocking evidence

The approved application itself does not reproduce every approved capture exactly. Multiple fresh complete runs failed first on `connect-inbox-390.png`: 18 raw RGBA pixels at rounded card edges. A two-animation-frame settling protocol applied identically to both application trees did not resolve it. The final diagnostic pass identified 12 of 72 scenes differing in at least one fresh capture (full RGB diagnostic table attached). Most differences are sparse rounded-border pixels; an enlarged-text Read capture also has a footer-region difference. Original and reconstructed/candidate samples are retained.

This establishes a capture reproducibility problem at unchanged application source, not evidence of an introduced application regression. Exact low-level cause remains unresolved: compositor/raster-cache behavior and layout/ResizeObserver pose are hypotheses, not proven root causes. Fonts, browser version, fixture clock and source identities are verified, but that does not establish deterministic painting.

No thresholds were increased, pixels masked, assertions deleted, baseline replaced or successful frame selected by retry. All failed runs remain evidence. The shallow Git checkout handling issue was corrected; a diagnostic output-directory issue was corrected before the final run. Neither explains the remaining pixel failure.

## State and next required action

Promotion readiness: **HOLD**. The immutable reference comparison is implemented locally but fails; it is not an established passing CI gate. No additional broad regression or deployment run was triggered after this failed gate. Prior accepted CI is not a substitute for the failing new comparison. Worktree tooling, documentation, approval record and 72 reference images remain uncommitted; app/runtime sources are unchanged.

Continue only targeted capture/renderer and enlarged-text pose reconciliation. A deterministic correction must reproduce the approved inventory at zero raw differences. If that is impossible without different reference pixels, present a separately evidenced replacement inventory for explicit owner approval; do not silently regenerate. Only then finish applicable CI and exact-head deployment verification. No 2B work or canonical promotion.

Final preservation check: all previously recorded remote refs unchanged, including canonical develop, main, PR #150 and recovery references. Production published deploy remains `6b00560bc816d49907a2911e`. No merge, migration, new branch, runtime/design change or production deployment occurred.
